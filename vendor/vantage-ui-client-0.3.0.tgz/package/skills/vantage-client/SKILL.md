---
name: vantage-client
description: Use when writing a web frontend (React or plain TypeScript) against a Vantage API served by vantage-server — connecting with @vantage-ui/client, generating typed models, reading collections, windows and records, writing, running actions, handling refusals and resync, and testing against MockServer.
metadata:
  version: "1.1.0"
---

# @vantage-ui/client

`@vantage-ui/client` turns a Vantage API (`api/<name>.yaml`, served by
vantage-server) into a typed, live object graph. Reads are lazy and stay
current: the server pushes changes, and a component re-renders on exactly
the fields it read. Writes are optimistic and roll back when the server
refuses them.

References in this skill:
- `references/react.md`: the provider, `observer`, and the hooks;
- `references/testing.md`: `createTestVantage` and `MockServer`;
- `references/protocol.md`: the wire frames, for scripts and debugging.

## Generate the types

The models come from the API's schema at `/v1/schema`. Install, generate,
test and build with local Node (22 or later) and npm; development needs no
Docker. Generate straight from the running server:

```sh
npx vantage-client generate --from http://127.0.0.1:<port>/v1/schema --out src/vantage.gen.ts
```

As an alternative, `--from` takes a saved copy of the schema, for when the
generator can't reach the server:

```sh
curl -fsS http://127.0.0.1:<port>/v1/schema -o schema.json
npx vantage-client generate --from schema.json --out src/vantage.gen.ts
```

The output follows the schema's order, so regenerating an unchanged schema
gives an identical file. Never edit `vantage.gen.ts`; regenerate it after
the API's YAML changes.

Per entity, the file has `XFields` (the record as data), `XInput` (what
`create()` takes) and the model `X`. A model has typed columns, a
`LazyReference` per reference, a `LazyCollection` per has-many, and a method
per row action. Model names come from entity names: entity `issues` gives
the model `Issues`.

## Connect

In the browser, the client connects to `/v1/ws` on the page's own origin.
Serve the frontend from vantage-server (the API's `frontend:` folder) and
no URL is needed:

```ts
// test: connect#same-origin
import { createVantage } from "@vantage-ui/client";
import { schema, type Schema } from "./vantage.gen";

const db = createVantage<Schema>({ schema, token: () => sessionStorage.getItem("vantage.token") ?? undefined });
```

`token` is sent in `hello` on every connect; a function is called each
time, so a new sign-in is picked up on the next reconnect. Outside a
browser (scripts, tests, Node), pass the URL:

```ts
// test: connect#script-url
// continues from the previous block: createVantage, schema, Schema
const db = createVantage<Schema>({ schema, url: "ws://127.0.0.1:8090/v1/ws", token: process.env.VANTAGE_TOKEN });
```

`db.ready` resolves with the connection (`{ status, halted, error? }`) once
the API's `instant` entities have loaded, or once the connection is refused
for good (see below).

## Read

Every entity is a property of `db`. Collections are lazy: reading one opens
it on the server, which then keeps its membership and records current. The
server filters, sorts and pages them; a collection has `map`, `forEach` and
iteration, but no `filter` or `find`. The same description gives the same
collection object, so a render can build one inline, with no `useMemo`.

```ts
// test: read#collections
// continues from Connect: db
const open = db.issues.where({ status: "open" }).sort("created_at", "desc");
await open.load();
const lines = open.map((issue) => `${issue.id}: ${issue.title}`);
const refusal = open.error; // the server's message if it refused the query, else null
```

`where` takes `{ column: value }` (equality), `{ column: [a, b] }` (in), or
`{ column: { gt: 3 } }` with `eq ne gt gte lt lte in not_in like`. A
reference may be named by its relation (`{ project: "JIR" }`). The API
decides which columns may be filtered and sorted (`params.filter`,
`sortable`); anything else is refused, and the refusal lands on `error`.

The generated `schema` carries those whitelists, and each enum column's
values in the API's order, so menus and chips needn't hard-code them:

```ts
// test: read#whitelists
import { schema } from "./vantage.gen";

const issues = schema.tables.issues;
const sortChoices = issues.sortable ?? Object.keys(issues.columns); // null: any column sorts
const filterable = issues.filter; // columns `where` may name
const statusChips = issues.columns.status.enum; // ["open", "in_progress", "done"]
const initialSort = issues.defaultSort; // { column, direction }, or null
```

For long lists, read one window at a time. Rows outside the window are not
sent. `window()` returns what has arrived so far (a row is `undefined` until
it loads); `whenLoaded()` waits for the window's rows. In React, `useWindow`
re-renders as they arrive instead.

```ts
// test: read#window
// continues from Connect: db
const page = await db.issues.sort("created_at", "desc").window(0, 50).whenLoaded();
const rows = page.items; // (Issues | undefined)[]
const fourth = page.at(3)?.title;
const scrollHeight = page.length * 32; // the server's total, else the rows so far
const footer = page.lengthExact ? `${page.length} issues` : `${page.length}+ issues`;
```

A window's `length` is the server's `total` when it sends one, and
otherwise the rows that have arrived without a gap. `lengthExact` says when
it is the real count: `totalExact` when there is a total (the server counts
exactly once it has sent the whole collection), else once a settled window
came back short. Size a scrollbar from `length` either way, but only show
it as a count when `lengthExact` is true. `settled` is true once the
window's rows have arrived or it failed, which is what `whenLoaded()` waits
for. A collection has `total` and `totalExact` the same way.

A window refused by the server, or waiting when the connection halts,
settles with `page.error` set.

One record, by id. `ref()` gives a `LazyReference`: `.value` is the model
once loaded (reading it starts the load, and is `undefined` until then);
`await` or `.load()` waits. A model's references are lazy the same way:

```ts
// test: read#records
// continues from Connect: db
const issue = await db.issues.ref("JIR-12").load(); // undefined when missing or refused
if (issue) {
  const project = await issue.project; // awaiting a reference loads its record
  const projectName = project?.name;
}
const ghost = db.issues.ref("JIR-404");
await ghost.load();
const status = ghost.status; // "missing"
```

Has-many references are collections through the parent (`via`), and narrow
like any other:

```ts
// test: read#via
// continues from Connect: db
const project = await db.projects.ref("JIR").load();
if (project) {
  const openInProject = await project.issues.where({ status: "open" }).load();
}
```

## Write

Writes are optimistic: the model shows the new value at once, and rolls
back (with `$errors` per field) if the server refuses.

```ts
// test: write#patch
// continues from Read: issue, loaded
const result = await issue.patch({ status: "done" });
if (!result.ok) console.warn(result.error.message, issue.$errors);
```

A draft collects several changes and sends them together. Everything a
draft adds is `$`-prefixed (`$flash()`, `$isDirty`, `$status`, `$errors`,
`$dirty(field)`, `$revert(field?)`), so any column stays editable on it:

```ts
// test: write#draft
// continues from Read: issue, loaded
const draft = issue.edit();
draft.title = "Login fails on Safari";
const saved = await draft.$flash();
```

```ts
// test: write#create
// continues from Connect: db
const created = await db.issues.create({ title: "Export to CSV", project: "JIR", status: "open" });
```

Writes made in one tick travel as one `batch` (not a transaction). The API's
`params.columns` limits which fields a write may set.

## Actions

Row actions are methods on the model; `$actions` lists the ones the server
allows on that row right now (their `when:` holds). Project actions are on
`db.run`; `kind: command` actions run as jobs whose output streams into
`db.jobs`.

```ts
// test: actions#row
// continues from Read: issue, loaded
if (issue.$actions.includes("close_issue")) {
  const closed = await issue.close_issue({ resolution: "fixed" });
  if (!closed.ok) console.error(closed.error.message);
}
```

```ts
// test: actions#job
// continues from Connect: db
const started = await db.run.triage({ project: "JIR" });
const job = started.ok ? db.jobs.peek().find((j) => j.job === started.job) : undefined;
```

In React, `useAction` wraps one for a button; see `references/react.md`.

## Connection states

`db.connection` is a signal of `{ status, halted, error? }`; `halted` is
true in the two final states:

| `status` | Meaning |
|---|---|
| `connecting` | Before the first `welcome` |
| `open` | Connected; reads and writes go out |
| `closed` | Lost; the client reconnects with backoff and resumes |
| `refused` | The server refused the token (at `hello`, or after an API reload). Final |
| `protocol_mismatch` | The server speaks another protocol version. Final |

After `refused` or `protocol_mismatch` the client stops reconnecting, and
everything waiting settles: `db.ready` resolves, and pending loads return
with `error` set to the server's message. Show it:

```ts
// test: connection#status
// continues from Connect: db; showBanner is your UI's
import { autorun } from "@vantage-ui/client";

const stop = autorun(() => {
  const { status, halted, error } = db.connection.get();
  if (halted) showBanner(`${status}: ${error}`);
});
```

In React, `useConnection()` gives the same; `references/react.md` shows a
provider fallback built on it.

## Refusals

The server refuses what the API doesn't allow (an unknown column, a filter
outside `params.filter`, a record outside your scope). A refusal never
throws and is never retried on its own:
- a collection or window has `error` (the message) and `loadState: "error"`;
- a record has `status: "error"` and `error` on its reference;
- a write or action returns `{ ok: false, error }`.

Change the query (a new `where` is a new collection) to try again.

## Resync

When the API's YAML changes, vantage-server reloads and sends `resync`. The
client reopens every collection and window on screen and reloads the
records it holds. Rows stay visible until the fresh ones arrive, so nothing
flashes empty. Refused collections and records get one more try under the
reloaded API. There is nothing to handle in app code.

## Scripts and the wire `where`

On the wire, `where` is a list of `[column, op, value]` tuples:
`[["status", "eq", "open"]]`. The client builds that from `.where({...})`;
only raw WebSocket scripts write it by hand (`references/protocol.md`).
