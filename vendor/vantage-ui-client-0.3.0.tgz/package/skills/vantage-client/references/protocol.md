# The wire protocol

JSON text frames over `ws(s)://<host>/v1/ws`, tagged by `t`. Requests carry
an `id`; replies echo it. The client handles all of this; read on for raw
scripts and debugging. HTTP: `/v1/schema` (the schema `generate` reads),
`/v1/health`, `/v1/ready` (503 naming entities whose datasource is down).

## Session

| Client → server | Server → client |
|---|---|
| `hello {protocol: 1, token?, cursor?, schema_hash?}` | `welcome {protocol, principal, epoch, seq, schema_hash, resync}` |
| | `error {kind, message, code: "protocol"}`, then close 1002: another protocol version |
| | `error {kind: "forbidden", message}`: the token is refused; the socket stays open for another `hello` |
| | `resync {epoch, seq, schema_hash}`: the API was reloaded; reopen what you show |
| | close 1008: after a reload, the API refuses the token |
| | close 1012 `reconnect`: the server is shutting down |

Nothing but `hello` is accepted before a `welcome`.

## Reading

| Client → server | Server → client |
|---|---|
| `open_table {table, where?, search?, sort?, via?, limit?}` | `rows {sub, start, ids, records, total, complete, seq}` |
| `viewport {sub, start, count}` | `members {sub, start, ids, records, total, complete}` |
| `close {sub}` | `members` pushed when membership or order changes |
| `open_records {table, ids}` | `records {records, missing}` |
| `interest {remove: [[table, id]]}` | `changed {seq, events: upsert \| removed \| invalidated}` |

`where` is a list of `[column, op, value]` tuples, `sort` is
`[column, "asc" | "desc"]`, and `via` is `{table, id, ref}` (a parent's
has-many). A refused request gets `error {id, kind, message}`.

## Writing and actions

| Client → server | Server → client |
|---|---|
| `flash {table, rid?, patch}` · `batch {items}` · `delete {table, rid}` | `flashed {rid, seq, record}` · `rejected {message, field_errors}` · `batch_result {results}` |
| `invoke {action, rid?, args}` | `result {seq, record?, job?}` · `job {job, action, state, …}` |
| `options {action, field, form?}` | `options_result {items}` |

## A raw script

```ts
// test: protocol#raw-script
const ws = new WebSocket("ws://127.0.0.1:8090/v1/ws");
ws.onopen = () => {
  ws.send(JSON.stringify({ t: "hello", id: 1, protocol: 1, token: process.env.VANTAGE_TOKEN }));
  ws.send(JSON.stringify({ t: "open_table", id: 2, table: "issues", where: [["status", "eq", "open"]], sort: ["created_at", "desc"], limit: 50 }));
};
ws.onmessage = (message) => console.log(JSON.parse(String(message.data)));
```

A WebSocket from a page on another origin is refused (403): `Origin` must
name the host the request was sent to. Scripts send no `Origin`.
