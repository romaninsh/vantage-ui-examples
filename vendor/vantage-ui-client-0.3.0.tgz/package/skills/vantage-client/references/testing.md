# Testing

`@vantage-ui/client/testing` has `MockServer`: an in-memory vantage-server
that speaks the same frames, with no network. Collections filter, sort,
window and follow `via` like the real one; writes broadcast `changed` and
move collection membership. Use it in unit tests and Storybook.

## With the generated schema

```ts
// test: testing#generated
import { createTestVantage } from "@vantage-ui/client/testing";
import { schema, type Schema } from "./vantage.gen";

const { db, server } = createTestVantage<Schema>(schema, {
  tables: { issues: [{ id: "JIR-1", title: "Login fails", status: "open", project: "JIR" }] },
  actions: { "issues.close_issue": () => ({ status: "done" }) },
});
await db.ready;
const issue = await db.issues.ref("JIR-1").load();
server.upsert("issues", { id: "JIR-1", title: "Login fails on Safari" }); // someone else's edit
```

Fixtures also take `available` (which row actions a record offers, standing
in for `when:`), `validate` (refuse writes with a message or field errors),
`protocol` (the version the mock speaks) and `refuseHello` (refuse every
token with a message).

A third argument passes client options, such as `{ token: "test" }`.

## Without generated types

`MockServer.withTable` builds a one-entity schema from the rows' keys.
`db.table(name)` reaches any entity by name:

```ts
// test: testing#one-table
import { MockServer, createTestVantage } from "@vantage-ui/client/testing";

const server = MockServer.withTable("issues", [{ id: "1", title: "First" }]);
const { db } = createTestVantage(server, { token: "test" });
const all = await db.table("issues").all.load();
```

## Refusals, held replies and resync

The server-side events a test can cause:
- `server.refuse(op, message)` answers every `op` frame (`open_table`,
  `open_records`, `viewport`, …) with that error; `server.allow(op)` stops it;
- `server.refuseWrites(message)` refuses every write, whether the client
  sends it alone or batched with others; `server.allowWrites()` stops it;
- `server.hold(op)` keeps `op` replies pending until `server.release(op)`;
- `server.resync()` is an API reload: a new journal, every collection gone,
  `resync` sent to every client;
- `server.invalidate(table)` is a coarse change: clients re-read the table;
- `server.opened` lists every collection a client opened (table, `where`,
  `sort`, …), refused ones too; `server.count(op)` counts the frames
  received, and `server.hellos` keeps every `hello`.

Assert on what the page asked for through these, not by spying on the
transport's frames:

```ts
// test: testing#opened
// continues from "Without generated types": server, db
import { expect } from "vitest";

await db.table("issues").where({ title: "First" }).load();
expect(server.opened.at(-1)).toEqual({ table: "issues", where: [["title", "eq", "First"]] });
server.refuseWrites("issues: column `title` is not writable");
const issue = await db.table("issues").ref("1").load();
const saved = await issue!.patch({ title: "Renamed" });
expect(saved.ok).toBe(false);
```

```ts
// test: testing#refusal
// continues from the previous block: server, db
import { expect } from "vitest";

server.refuse("open_table", "invalid column `x` is not filterable");
const refused = await db.table("issues").where({ x: 1 }).load();
expect(refused.error).toBe("invalid column `x` is not filterable");
expect(server.count("open_table")).toBe(1); // a refusal is not retried
```

```ts
// test: testing#resync
// continues from "Without generated types": server, db
import { expect } from "vitest";

const rows = () => db.table("issues").all.map((r) => r.title);
const settle = () => new Promise((resolve) => setTimeout(resolve, 5));
await db.table("issues").all.load();
server.setRows("issues", [{ id: "1", title: "First, renamed" }]); // the reloaded API's data

server.hold("open_table"); // keep the reopen pending
server.resync();
await settle();
expect(rows()).toEqual(["First"]); // still shown, no flash to empty
server.release("open_table");
await settle();
expect(rows()).toEqual(["First, renamed"]);
```

`transport.drop()` (from `createTestVantage`'s result) simulates a lost
connection; `transport.drop(1008, reason)` a refused one.
