# React

Import the bindings from `@vantage-ui/client/react`. React 18 or later.

## The provider, and the connection's states

`VantageProvider` makes `db` available to `useVantage()`. With a `fallback`,
its children wait for `db.ready`: the `instant` entities loaded, or a final
refusal. One component can serve as the fallback and as a gate that
explains `refused` and `protocol_mismatch` once the children show:

```tsx
// test: react#provider
// continues from SKILL.md's Connect: db; App is your app's root component
import { VantageProvider, useConnection } from "@vantage-ui/client/react";
import type { ReactNode } from "react";

function ConnectionGate({ children }: { children?: ReactNode }) {
  const { status, error } = useConnection();
  if (status === "refused") return <p role="alert">Sign-in refused: {error}</p>;
  if (status === "protocol_mismatch") return <p role="alert">This page is out of date. Reload it. ({error})</p>;
  return children ?? <p>Connecting…</p>;
}

function Root() {
  return (
    <VantageProvider db={db} fallback={<ConnectionGate />}>
      <ConnectionGate>
        <App />
      </ConnectionGate>
    </VantageProvider>
  );
}
```

`useConnection()` returns `{ status, halted, error, seq, principal }`;
`halted` is true once `refused` or `protocol_mismatch`. `closed` is
transient (the client reconnects); show it as a hint, not an error.

## observer

`observer(Component)` re-renders a component when anything it read during
render changes: a field, a collection's members, a reference's value. It
re-renders on nothing else.

```tsx
// test: react#collection
import { observer, useCollection, useVantage } from "@vantage-ui/client/react";
import type { Schema } from "./vantage.gen";

const OpenIssues = observer(() => {
  const db = useVantage<Schema>();
  const { items, loadState, error } = useCollection(db.issues.where({ status: "open" }));
  if (error) return <p role="alert">{error}</p>;
  if (loadState === "loading") return <p>Loading…</p>;
  return <ul>{items.map((issue) => <li key={issue.id}>{issue.title}</li>)}</ul>;
});
```

`useCollection` returns `{ items, loadState, total, totalExact, length, error }`.
Build the collection inline, as above: the same description is the same
object, so it needs no `useMemo`.

## Windows

For virtualised lists, `useWindow(collection, start, count)` gives the rows
`start..start+count`. Moving `start` moves the server's window; rows stay
on screen until the new ones arrive. Size the virtualiser from
`page.length`, show it as a count only when `page.lengthExact`, and use
`page.settled` to tell "still loading" from "no rows here".

```tsx
// test: react#window
import { observer, useVantage, useWindow } from "@vantage-ui/client/react";
import type { Schema } from "./vantage.gen";

const IssueRows = observer(({ start }: { start: number }) => {
  const page = useWindow(useVantage<Schema>().issues.sort("created_at", "desc"), start, 50);
  if (page.error) return <p role="alert">{page.error}</p>;
  return <>{page.items.map((issue, i) => <div key={start + i}>{issue?.title ?? "…"}</div>)}</>;
});
```

## One record

`useRecord(reference)` returns `{ value, status, error }`. `status` is
`none`, `loading`, `loaded`, `missing` or `error`; `error` holds the
server's message when it refused the record. Unlike collections, each
`ref()` call is a new reference, so keep it stable with `useMemo`:

```tsx
// test: react#record
import { useRecord, useVantage } from "@vantage-ui/client/react";
import { useMemo } from "react";
import type { Schema } from "./vantage.gen";

function IssueTitle({ id }: { id: string }) {
  const db = useVantage<Schema>();
  const ref = useMemo(() => db.issues.ref(id), [db, id]);
  const { value, status, error } = useRecord(ref);
  if (status === "error") return <p role="alert">{error}</p>;
  if (status === "missing") return <p>No issue {id}</p>;
  return <h1>{value?.title ?? "…"}</h1>;
}
```

`useHydrated(target, keys?)` suspends until a model's references, a
reference or a collection have loaded; wrap the component in `<Suspense>`.
It also stops suspending when the server refuses the load or the
connection halts: the collection's `error`, or the reference's `error`
(with `status: "error"`), then holds the message.

## Actions

`useAction(fn)` wraps an action for a button: `run`, `pending`, and the last
`error`. Call row actions on the model inside the function, so `this` is
kept:

```tsx
// test: react#action
import { observer, useAction } from "@vantage-ui/client/react";
import type { Issues } from "./vantage.gen";

const CloseButton = observer(({ issue }: { issue: Issues }) => {
  const close = useAction(() => issue.close_issue({ resolution: "fixed" }));
  if (!issue.$actions.includes("close_issue")) return null;
  return (
    <>
      <button disabled={close.pending} onClick={() => void close.run()}>Close</button>
      {close.error && <span role="alert">{close.error.message}</span>}
    </>
  );
});
```

## Drafts in forms

`useServo(model)` gives an edit draft that re-renders the form as it
changes: set fields, read `$isDirty`, `$status` and `$errors`, then
`$flash()`.

## Other hooks

- `useJobs()`: running and finished jobs, newest first, with their output lines.
- `usePreloadOnIntent(load)`: starts `load` when the pointer rests on an
  element, so the data is there by the click.
- `useLive(fn, deps)`: any derived value, recomputed when what it reads changes.
