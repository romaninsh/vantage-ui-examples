# Changelog

## 0.3.0 — 2026-10-13

- Connects to `/v1/ws` on the page's origin by default; outside a browser a `url` is required.
- `hello` sends `protocol: 1` and the `token` option.
- `db.connection` is `{ status, halted, error? }`: `online`/`offline` became `open`/`closed`, plus final `refused` and `protocol_mismatch` (`halted`); `db.ready` settles on them and resolves with the connection. `useConnection()` returns `halted` too.
- `resync` reopens what is shown without flashing rows; refusals land on `error` and are not retried.
- `useRecord` returns `{ value, status, error }`; collections and windows carry `error`.
- Windows add `total`, `totalExact`, `settled`, `length`, `lengthExact` and `whenLoaded()`; collections and `useCollection` add `totalExact`.
- The same collection description gives the same object while it is in use.
- Removed: `filter`/`find`/`some`/`every` on collections, and the root exports `Reaction`, `track`, `untracked`, `WebSocketTransport`, `defaultUrl`, `PROTOCOL`, `uuidv7` and `DraftFields`. `Vantage` is exported as a type only, and internal members are left out of the published types.
- `observer` keeps a generic component's type.
- MockServer adds `opened` and `refuseWrites`/`allowWrites`.
- Edits queued while offline are sent on reconnect in the same page only; a reload loses them.
- Draft members are `$`-prefixed (`$flash`, `$isDirty`, `$status`, `$errors`, `$dirty`, `$revert`); columns, references and row actions with reserved names are refused.
- `npx vantage-client generate --from <url | file>` replaces the Rust `generate-ts`; it reads the running server's `/v1/schema` directly.
- Development runs on local Node 22+; no Docker.
- The generated `schema` carries `sortable`, `filter`, `defaultSort` (`{ column, direction }`) and each enum column's values; labels in generated comments are escaped.
- Ships an ESM build with types, the `generate` CLI, and the `vantage-client` skill.
