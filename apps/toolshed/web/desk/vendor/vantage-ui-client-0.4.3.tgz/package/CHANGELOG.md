# Changelog

## 0.4.3 — 2026-10-13

- A run delivers to `on`/`useRunMessage` the messages sent while the connection was down or across a `resync`, from the server's `seq` on each message.

## 0.4.2 — 2026-10-13

- MockServer fixture `actions` also accept a project action's YAML key with dashes (`check-overdue` for `check_overdue`); naming one action both ways throws.
- Docs: fixture action keys are wire names, handlers are typed with `ActionHandler` and `MockRunControl`, and `run.start()` on a finished run begins a new run.
- Docs: rebuilding a list from `run.messages` after a reload, `start()` with no argument, and why `XFields` columns are nullable.

## 0.4.1 — 2026-10-13

- `db.reconnect()` connects again after `refused`, calling `token` afresh, for a sign-in form.
- The generated file's header says how it is regenerated: by the web dev container from `schema.json`, or with `npx vantage-client generate`.

## 0.4.0 — 2026-10-13

- Actions run as runs: `db.run.<action>` and `model.$run.<action>` give `start(args, { run? })`, `attach(id)` and `idle()`; a `Run` has reactive `status`, `state`, `result`, `error` and `messages`, plus `on`, `set` (inputs, optimistic), `cancel` and `done`. Breaking: `db.run.x(input)` is now `db.run.x.start(input)`.
- Row and toolbar action methods run the action and wait for its end; they no longer return the server's record.
- React: `useRun(factory, { key })` (re-attaches after a page reload), `useShared` and `useRunMessage`.
- `generate` emits `<Action>Run` (`args`, `state`, `inputs`, `messages`) per action and `$run` on models; the runtime schema carries each action's `state` and `messages`.
- `hello` sends `features: ["runs:1"]`; a server without it fails runs with a clear message. An unanswered `start` is sent again with the same id after a reconnect or `resync`, and running runs attach again; unknown frames, fields and statuses are ignored.
- `run.on`/`useRunMessage` take `vantage.notify` and `vantage.log`; `run.forget()` returns a run to `idle`; `useRun` keys are scoped to the action.
- Removed: `db.jobs`, `stopJob`, `useJobs`, the `Job` type and `ActionResult.job`.
- MockServer runs action handlers as runs (`(row, args, run)`), with `server.runs`.

## 0.3.0 — 2026-10-13

- Connects to `/v1/ws` on the page's origin by default; outside a browser a `url` is required.
- `hello` sends `protocol: 1` and the `token` option.
- `db.connection` is `{ status, halted, error? }`: `online`/`offline` became `open`/`closed`, plus final `refused` and `protocol_mismatch` (`halted`); `db.ready` settles on them and resolves with the connection. `useConnection()` returns `halted` too.
- `resync` reopens what is shown without flashing rows; refusals land on `error` and are not retried.
- `useRecord` returns `{ value, status, error }`; collections and windows carry `error`.
- Windows add `total`, `totalExact`, `settled`, `length`, `lengthExact` and `whenLoaded()`; collections and `useCollection` add `totalExact`.
- The same collection description gives the same object while it is in use.
- Removed: `filter`/`find`/`some`/`every` on collections, and the root exports `Reaction`, `track`, `untracked`, `WebSocketTransport`, `defaultUrl`, `PROTOCOL`, `uuidv7` and `DraftFields`. `Vantage` is exported as a type only, and internal members are left out of the published types.
- `observer` keeps a generic component's type.
- MockServer adds `opened` and `refuseWrites`/`allowWrites`.
- Edits queued while offline are sent on reconnect in the same page only; a reload loses them.
- Draft members are `$`-prefixed (`$flash`, `$isDirty`, `$status`, `$errors`, `$dirty`, `$revert`); columns, references and row actions with reserved names are refused.
- `npx vantage-client generate --from <url | file>` replaces the Rust `generate-ts`; it reads the running server's `/v1/schema` directly.
- Development runs on local Node 22+; no Docker.
- The generated `schema` carries `sortable`, `filter`, `defaultSort` (`{ column, direction }`) and each enum column's values; labels in generated comments are escaped.
- Ships an ESM build with types, the `generate` CLI, and the `vantage-client` skill.
