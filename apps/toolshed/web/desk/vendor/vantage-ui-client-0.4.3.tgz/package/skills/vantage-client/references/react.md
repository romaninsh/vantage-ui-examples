# React

Import the bindings from `@vantage-ui/client/react`. React 18 or later.

## The provider, and the connection's states

`VantageProvider` makes `db` available to `useVantage()`. With a `fallback`,
its children wait for `db.ready`: the `instant` entities loaded, or a final
refusal. One component can serve as the fallback and as a gate that
explains `refused` and `protocol_mismatch` once the children show:

```tsx
// test: react#provider
// continues from SKILL.md's Connect: db; App is your app's root component
import { VantageProvider, useConnection } from "@vantage-ui/client/react";
import type { ReactNode } from "react";

function ConnectionGate({ children }: { children?: ReactNode }) {
  const { status, error } = useConnection();
  if (status === "refused") return <p role="alert">Sign-in refused: {error}</p>;
  if (status === "protocol_mismatch") return <p role="alert">This page is out of date. Reload it. ({error})</p>;
  return children ?? <p>Connecting…</p>;
}

function Root() {
  return (
    <VantageProvider db={db} fallback={<ConnectionGate />}>
      <ConnectionGate>
        <App />
      </ConnectionGate>
    </VantageProvider>
  );
}
```

`useConnection()` returns `{ status, halted, error, seq, principal }`;
`halted` is true once `refused` or `protocol_mismatch`. `closed` is
transient (the client reconnects); show it as a hint, not an error. A
sign-in form shown for `refused` stores the new token and calls
`useVantage().reconnect()`; the gate shows the children again once the
connection opens (SKILL.md, Connection states).

## observer

`observer(Component)` re-renders a component when anything it read during
render changes: a field, a collection's members, a reference's value. It
re-renders on nothing else.

```tsx
// test: react#collection
import { observer, useCollection, useVantage } from "@vantage-ui/client/react";
import type { Schema } from "./vantage.gen";

const OpenIssues = observer(() => {
  const db = useVantage<Schema>();
  const { items, loadState, error } = useCollection(db.issues.where({ status: "open" }));
  if (error) return <p role="alert">{error}</p>;
  if (loadState === "loading") return <p>Loading…</p>;
  return <ul>{items.map((issue) => <li key={issue.id}>{issue.title}</li>)}</ul>;
});
```

`useCollection` returns `{ items, loadState, total, totalExact, length, error }`.
Build the collection inline, as above: the same description is the same
object, so it needs no `useMemo`.

## Windows

For virtualised lists, `useWindow(collection, start, count)` gives the rows
`start..start+count`. Moving `start` moves the server's window; rows stay
on screen until the new ones arrive. Size the virtualiser from
`page.length`, show it as a count only when `page.lengthExact`, and use
`page.settled` to tell "still loading" from "no rows here".

```tsx
// test: react#window
import { observer, useVantage, useWindow } from "@vantage-ui/client/react";
import type { Schema } from "./vantage.gen";

const IssueRows = observer(({ start }: { start: number }) => {
  const page = useWindow(useVantage<Schema>().issues.sort("created_at", "desc"), start, 50);
  if (page.error) return <p role="alert">{page.error}</p>;
  return <>{page.items.map((issue, i) => <div key={start + i}>{issue?.title ?? "…"}</div>)}</>;
});
```

## One record

`useRecord(reference)` returns `{ value, status, error }`. `status` is
`none`, `loading`, `loaded`, `missing` or `error`; `error` holds the
server's message when it refused the record. Unlike collections, each
`ref()` call is a new reference, so keep it stable with `useMemo`:

```tsx
// test: react#record
import { useRecord, useVantage } from "@vantage-ui/client/react";
import { useMemo } from "react";
import type { Schema } from "./vantage.gen";

function IssueTitle({ id }: { id: string }) {
  const db = useVantage<Schema>();
  const ref = useMemo(() => db.issues.ref(id), [db, id]);
  const { value, status, error } = useRecord(ref);
  if (status === "error") return <p role="alert">{error}</p>;
  if (status === "missing") return <p>No issue {id}</p>;
  return <h1>{value?.title ?? "…"}</h1>;
}
```

`useHydrated(target, keys?)` suspends until a model's references, a
reference or a collection have loaded; wrap the component in `<Suspense>`.
It also stops suspending when the server refuses the load or the
connection halts: the collection's `error`, or the reference's `error`
(with `status: "error"`), then holds the message.

## Actions

`useAction(fn)` wraps an action for a button: `run`, `pending`, and the last
`error`. Call row actions on the model inside the function, so `this` is
kept:

```tsx
// test: react#action
import { observer, useAction } from "@vantage-ui/client/react";
import type { Issues } from "./vantage.gen";

const CloseButton = observer(({ issue }: { issue: Issues }) => {
  const close = useAction(() => issue.close_issue({ resolution: "fixed" }));
  if (!issue.$actions.includes("close_issue")) return null;
  return (
    <>
      <button disabled={close.pending} onClick={() => void close.run()}>Close</button>
      {close.error && <span role="alert">{close.error.message}</span>}
    </>
  );
});
```

## Runs

`useRun(db.run.<action>, { key? })` gives the component one run, idle until
`start`. With `key`, its id is kept in the tab's `sessionStorage`, per
action: after a page reload the same component attaches to the run again
and continues from its current state. A stored run the server no longer has
(expired, or not yours) is forgotten and the run is `idle` again;
`run.forget()` does the same on purpose, to stop showing a finished run. A
new `key` is a new run.
`useShared(run, "name")` reads one variable, or gives `[value, set]` for an
input; only components that read a variable re-render when it changes.
`useRunMessage(run, "name", fn)` calls `fn` for each message while mounted,
in order; `"vantage.notify"` is the body's `notify(text)` (`m.text`).

```tsx
// test: react#run
import { useRun, useRunMessage, useShared, useVantage } from "@vantage-ui/client/react";
import type { Schema } from "./vantage.gen";

// notifyUser is your UI's
function Triage({ project }: { project: string }) {
  const db = useVantage<Schema>();
  const triage = useRun(db.run.triage, { key: `triage:${project}` });
  const progress = useShared(triage, "progress");
  const total = useShared(triage, "total");
  const [confirmed, setConfirmed] = useShared(triage, "confirmed");
  useRunMessage(triage, "flagged", (m) => notifyUser(`${m.issue} has no assignee`));
  useRunMessage(triage, "vantage.notify", (m) => notifyUser(m.text));
  if (triage.status === "idle") return <button onClick={() => triage.start({ project })}>Triage</button>;
  if (triage.status === "running" && !confirmed) return <button onClick={() => void setConfirmed(true)}>Confirm {total} issues</button>;
  return <progress value={progress} max={total || 1} />;
}
```

`useRunMessage` hears only the messages that arrive while the component is
mounted. After a page reload, the run attaches, and the messages sent
before then come back as history in `run.messages`, not as events. A list
that has to survive a reload (the issues a run flagged) is therefore built
from `run.messages`, in an `observer` component so that it re-renders as
messages arrive. Each entry is
`{ name, payload }`, oldest first. The list holds the run's last 100
messages, the framework's `vantage.notify` and `vantage.log` included.
Compare `name` to pick out one kind of message; the comparison narrows
`payload` to that message's type:

```tsx
// test: react#run-history
import { observer, useRun, useVantage } from "@vantage-ui/client/react";
import type { Schema } from "./vantage.gen";

const Flagged = observer(() => {
  const db = useVantage<Schema>();
  const triage = useRun(db.run.triage, { key: "triage:JIR" });
  const flagged = triage.messages.flatMap((m) => (m.name === "flagged" ? [m.payload.issue] : []));
  if (triage.status === "idle") return <button onClick={() => triage.start({ project: "JIR" })}>Triage</button>;
  return <ul>{flagged.map((issue) => <li key={issue}>{issue} has no assignee</li>)}</ul>;
});
```

Forms, confirms and multi-step wizards are your components: collect what
the action needs, then `start` it once with the values.

`run.start(args)` always begins a new run with a new id; it never attaches.
On a finished run (`done`, `failed`, `cancelled`) that is "run it again":
no `forget()` first. With a `key`, the new id replaces the stored one. A
page reload shows the last run, finished or not, until the next `start`.
On a running run, `start` switches the handle to the new run and leaves
the old one running on the server; `cancel()` it first if it should stop.

`check.start()` with no argument type-checks when the action declares no
args (the generated `args` is `{}`), or when all its args are optional;
`start({})` means the same. When an arg is required, the argument is
required too, and leaving it out is a type error.

```tsx
// test: react#run-again
import { useRun, useShared, useVantage } from "@vantage-ui/client/react";
import type { Schema } from "./vantage.gen";

function CheckOverdue() {
  const db = useVantage<Schema>();
  const check = useRun(db.run.check_overdue, { key: "desk" });
  const overdue = useShared(check, "overdue");
  const busy = check.status === "starting" || check.status === "running";
  return (
    <>
      <button disabled={busy} onClick={() => check.start()}>Check overdue loans</button>
      {check.status === "done" && <p>{overdue} overdue</p>}
    </>
  );
}
```

## Drafts in forms

`useServo(model)` gives an edit draft that re-renders the form as it
changes: set fields, read `$isDirty`, `$status` and `$errors`, then
`$flash()`.

## Other hooks

- `usePreloadOnIntent(load)`: starts `load` when the pointer rests on an
  element, so the data is there by the click.
- `useLive(fn, deps)`: any derived value, recomputed when what it reads changes.
